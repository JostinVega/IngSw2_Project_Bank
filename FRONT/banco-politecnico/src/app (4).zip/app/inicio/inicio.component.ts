/*import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit, AfterViewInit {
  currentIndex: number = 0;
  totalCards: number = 0;

  constructor(
    private renderer: Renderer2,
    private router: Router
  ) {}

  ngOnInit(): void {
    window.addEventListener('resize', this.updateNavigation.bind(this));
  }

  ngAfterViewInit(): void {
    this.totalCards = document.querySelectorAll('.account-card').length;
    this.updateNavigation();
  }

  updateNavigation(): void {
    const accountCardsWrapper = document.getElementById('accountCardsWrapper');
    const accountNavLeft = document.getElementById('accountNavLeft');
    const accountNavRight = document.getElementById('accountNavRight');

    if (!accountCardsWrapper || !accountNavLeft || !accountNavRight) {
      return;
    }

    const cardWidth = accountCardsWrapper.children[0].clientWidth + 20; // Card width + margin

    if (this.totalCards <= 2) {
      this.renderer.setStyle(accountNavLeft, 'display', 'none');
      this.renderer.setStyle(accountNavRight, 'display', 'none');
    } else {
      this.renderer.setStyle(accountNavLeft, 'display', this.currentIndex === 0 ? 'none' : 'flex');
      this.renderer.setStyle(accountNavRight, 'display', this.currentIndex >= this.totalCards - 2 ? 'none' : 'flex');
    }

    const offset = -this.currentIndex * cardWidth;
    this.renderer.setStyle(accountCardsWrapper, 'transform', `translateX(${offset}px)`);
  }

  navLeft(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.updateNavigation();
    }
  }

  navRight(): void {
    if (this.currentIndex < this.totalCards - 2) {
      this.currentIndex++;
      this.updateNavigation();
    }
  }
}*/

/*import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../services/account.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit, AfterViewInit {
  currentIndex: number = 0;
  totalCards: number = 0;
  cuentas: any[] = [];

  constructor(
    private renderer: Renderer2,
    private router: Router,
    private accountService: AccountService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    window.addEventListener('resize', this.updateNavigation.bind(this));
    this.loadUserAccounts();
  }

  ngAfterViewInit(): void {
    this.updateNavigation();
  }

  loadUserAccounts(): void {
    const nombreUsuario = this.authService.getNombreUsuario();
    if (nombreUsuario) {
      this.accountService.getAccounts(nombreUsuario).subscribe(
        (response: any) => {
          this.cuentas = response.cuentas;
          this.totalCards = this.cuentas.length;
          this.updateNavigation();
        },
        (error: any) => {
          console.error('Error al obtener las cuentas:', error);
        }
      );
    }
  }

  updateNavigation(): void {
    const accountCardsWrapper = document.getElementById('accountCardsWrapper');
    const accountNavLeft = document.getElementById('accountNavLeft');
    const accountNavRight = document.getElementById('accountNavRight');

    if (!accountCardsWrapper || !accountNavLeft || !accountNavRight) {
      return;
    }

    const cardWidth = accountCardsWrapper.children[0]?.clientWidth + 20; // Card width + margin

    if (this.totalCards <= 2) {
      this.renderer.setStyle(accountNavLeft, 'display', 'none');
      this.renderer.setStyle(accountNavRight, 'display', 'none');
    } else {
      this.renderer.setStyle(accountNavLeft, 'display', this.currentIndex === 0 ? 'none' : 'flex');
      this.renderer.setStyle(accountNavRight, 'display', this.currentIndex >= this.totalCards - 2 ? 'none' : 'flex');
    }

    const offset = -this.currentIndex * cardWidth;
    this.renderer.setStyle(accountCardsWrapper, 'transform', `translateX(${offset}px)`);
  }

  navLeft(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.updateNavigation();
    }
  }

  navRight(): void {
    if (this.currentIndex < this.totalCards - 2) {
      this.currentIndex++;
      this.updateNavigation();
    }
  }
}

*/

/*import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../services/account.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit, AfterViewInit {
  currentIndex: number = 0;
  totalCards: number = 0;
  cuentas: any[] = [];

  constructor(
    private renderer: Renderer2,
    private router: Router,
    private accountService: AccountService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    window.addEventListener('resize', this.updateNavigation.bind(this));
    this.loadUserAccounts();
  }

  ngAfterViewInit(): void {
    this.updateNavigation();
  }

  loadUserAccounts(): void {
    const nombreUsuario = this.authService.getNombreUsuario();
    if (nombreUsuario) {
      this.accountService.getAccounts(nombreUsuario).subscribe(
        (response: any) => {
          this.cuentas = response.cuentas;
          this.totalCards = this.cuentas.length;
          this.updateNavigation();
        },
        (error: any) => {
          console.error('Error al obtener las cuentas:', error);
        }
      );
    }
  }

  updateNavigation(): void {
    const accountCardsWrapper = document.getElementById('accountCardsWrapper');
    const accountNavLeft = document.getElementById('accountNavLeft');
    const accountNavRight = document.getElementById('accountNavRight');

    if (!accountCardsWrapper || !accountNavLeft || !accountNavRight) {
      return;
    }

    const cardWidth = accountCardsWrapper.children[0]?.clientWidth + 20; // Card width + margin

    if (this.totalCards <= 2) {
      this.renderer.setStyle(accountNavLeft, 'display', 'none');
      this.renderer.setStyle(accountNavRight, 'display', 'none');
    } else {
      this.renderer.setStyle(accountNavLeft, 'display', this.currentIndex === 0 ? 'none' : 'flex');
      this.renderer.setStyle(accountNavRight, 'display', this.currentIndex >= this.totalCards - 2 ? 'none' : 'flex');
    }

    const offset = -this.currentIndex * cardWidth;
    this.renderer.setStyle(accountCardsWrapper, 'transform', `translateX(${offset}px)`);
  }

  navLeft(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.updateNavigation();
    }
  }

  navRight(): void {
    if (this.currentIndex < this.totalCards - 2) {
      this.currentIndex++;
      this.updateNavigation();
    }
  }
}
*/

/*import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../services/account.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit, AfterViewInit {
  currentIndex: number = 0;
  totalCards: number = 0;
  cuentas: any[] = [];
  quickAccessItems: any[] = [
    {
      icon: 'assets/img/transfer-icon.png',
      label: 'Transferencias',
      link: '/transferencias'
    },
    {
      icon: 'assets/img/bill-icon.png',
      label: 'Pago de Facturas',
      link: '/pagos-facturas'
    }
    // Agrega más accesos rápidos según sea necesario
  ];

  constructor(
    private renderer: Renderer2,
    private router: Router,
    private accountService: AccountService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    window.addEventListener('resize', this.updateNavigation.bind(this));
    this.loadUserAccounts();
  }

  ngAfterViewInit(): void {
    this.updateNavigation();
  }

  loadUserAccounts(): void {
    const nombreUsuario = this.authService.getNombreUsuario();
    if (nombreUsuario) {
      this.accountService.getAccounts(nombreUsuario).subscribe(
        (response: any) => {
          this.cuentas = response.cuentas;
          this.totalCards = this.cuentas.length;
          this.updateNavigation();
        },
        (error: any) => {
          console.error('Error al obtener las cuentas:', error);
        }
      );
    }
  }

  updateNavigation(): void {
    const accountCardsWrapper = document.getElementById('accountCardsWrapper');
    const accountNavLeft = document.getElementById('accountNavLeft');
    const accountNavRight = document.getElementById('accountNavRight');

    if (!accountCardsWrapper || !accountNavLeft || !accountNavRight) {
      return;
    }

    const cardWidth = accountCardsWrapper.children[0]?.clientWidth + 20; // Card width + margin

    if (this.totalCards <= 2) {
      this.renderer.setStyle(accountNavLeft, 'display', 'none');
      this.renderer.setStyle(accountNavRight, 'display', 'none');
    } else {
      this.renderer.setStyle(accountNavLeft, 'display', this.currentIndex === 0 ? 'none' : 'flex');
      this.renderer.setStyle(accountNavRight, 'display', this.currentIndex >= this.totalCards - 2 ? 'none' : 'flex');
    }

    const offset = -this.currentIndex * cardWidth;
    this.renderer.setStyle(accountCardsWrapper, 'transform', `translateX(${offset}px)`);
  }

  navLeft(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.updateNavigation();
    }
  }

  navRight(): void {
    if (this.currentIndex < this.totalCards - 2) {
      this.currentIndex++;
      this.updateNavigation();
    }
  }
}
*/

import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit, AfterViewInit {
  currentIndex: number = 0;
  totalCards: number = 0;
  accounts: any[] = []; // Store fetched accounts data

  constructor(
    private renderer: Renderer2,
    private router: Router,
    private authService: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    window.addEventListener('resize', this.updateNavigation.bind(this));
    this.fetchAccounts();
  }

  ngAfterViewInit(): void {
    this.totalCards = document.querySelectorAll('.account-card').length;
    this.updateNavigation();
  }

  fetchAccounts(): void {
    const currentUser = this.authService.getNombreUsuario();
    if (currentUser) {
      this.http.get<any[]>(`accounts?user=${currentUser}`).subscribe(
        data => {
          this.accounts = data;
          this.totalCards = this.accounts.length;
          this.updateNavigation();
        },
        error => {
          console.error('Error fetching accounts:', error);
        }
      );
    } else {
      console.error('No logged-in user');
    }
  }

  updateNavigation(): void {
    const accountCardsWrapper = document.getElementById('accountCardsWrapper');
    const accountNavLeft = document.getElementById('accountNavLeft');
    const accountNavRight = document.getElementById('accountNavRight');

    if (!accountCardsWrapper || !accountNavLeft || !accountNavRight) {
      return;
    }

    const cardWidth = accountCardsWrapper.children[0]?.clientWidth + 20; // Card width + margin

    if (this.totalCards <= 2) {
      this.renderer.setStyle(accountNavLeft, 'display', 'none');
      this.renderer.setStyle(accountNavRight, 'display', 'none');
    } else {
      this.renderer.setStyle(accountNavLeft, 'display', this.currentIndex === 0 ? 'none' : 'flex');
      this.renderer.setStyle(accountNavRight, 'display', this.currentIndex >= this.totalCards - 2 ? 'none' : 'flex');
    }

    const offset = -this.currentIndex * cardWidth;
    this.renderer.setStyle(accountCardsWrapper, 'transform', `translateX(${offset}px)`);
  }

  navLeft(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.updateNavigation();
    }
  }

  navRight(): void {
    if (this.currentIndex < this.totalCards - 2) {
      this.currentIndex++;
      this.updateNavigation();
    }
  }
}
