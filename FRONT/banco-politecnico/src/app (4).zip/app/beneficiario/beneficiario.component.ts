import { Component, OnInit } from '@angular/core';
import { ContactService } from '../services/contact.service'; // Asegúrate de ajustar la ruta según la ubicación de tu servicio
import { Router } from '@angular/router';

@Component({
  selector: 'app-beneficiario',
  templateUrl: './beneficiario.component.html',
  styleUrls: ['./beneficiario.component.css']
})
export class BeneficiarioComponent implements OnInit {
  showModal = false; // Agrega la propiedad showModal si la necesitas en este componente

  searchTerm: string = '';
  contacts: any[] = [];
  filteredContacts: any[] = [];
  
  selectedContactIndex: number | null = null;
  selectedContact: any = null; // Variable para almacenar el contacto seleccionado
  searchQuery: string = '';

  constructor(private contactService: ContactService, private router: Router) { }
  /*
  ngOnInit(): void {
    this.actualizarListaContactos();
  }
    */
  ngOnInit(): void {
    this.loadContacts();
  }
  

  actualizarListaContactos(): void {
    this.filteredContacts = this.contactService.getContacts();
  }

  loadContacts(): void {
    this.contacts = this.contactService.getContacts();
    console.log(this.contacts); // Verificar el orden en la consola
    this.filteredContacts = [...this.contacts]; // Copia de los contactos para usar en la vista
  }
  
  /*
  filterContacts(): void {
    this.contacts = this.contactService.getContacts().filter(contact => 
      contact.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      contact.accountNumber.includes(this.searchTerm)
    );
  }
  */

  filterContacts(): void {
    if (this.searchTerm) {
      this.filteredContacts = this.contacts.filter(contact => 
        contact.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        contact.number.includes(this.searchTerm)
      );
    } else {
      this.filteredContacts = [...this.contacts];
    }
  }
  

  // Agrega el método para añadir beneficiarios desde agregar-beneficiario.component
  addBeneficiary(contact: any): void {
    this.contactService.addContact(contact);
    this.contacts = this.contactService.getContacts(); // Actualiza la lista de contactos
  }
  
 

  // Agrega este método al componente
  selectContact(contact: any): void {
      this.selectedContact = contact;
      console.log('Contacto seleccionado:', contact);
  }

  // Modifica el método toggleMenu para evitar el evento click
  toggleMenu(index: number, event: Event): void {
      event.stopPropagation();
      if (this.selectedContactIndex === index) {
          this.selectedContactIndex = null;
      } else {
          this.selectedContactIndex = index;
      }
  }


  deleteContact(index: number): void {
    this.contacts.splice(index, 1);
    this.filterContacts();
    this.selectedContactIndex = null;
    this.loadContacts(); // Recargar los contactos después de eliminar

  }

  goBack(): void {
    // Implementar la lógica para volver a la página anterior
    console.log('Volver a la página anterior');
    this.router.navigate(['/transfer']);
  }

  addFavorite(contact: any): void {
    // Aquí puedes agregar la lógica para marcar como favorito
    console.log('Agregado como favorito:', contact);
    this.selectedContactIndex = null;
    /*this.selectedContactIndex = null;*/
    this.contactService.markAsFavorite(contact.number);
    this.loadContacts(); // Recargar los contactos después de marcar como favorito

  }

  continue(): void {
    if (this.selectedContact) {
      this.router.navigate(['/confirmar-transferencia']);
    } else {
      console.log('Seleccione un contacto antes de continuar.');
    }
  }

  // Define el método goToBeneficiario si lo necesitas en este componente
  goToBeneficiario(): void {
    this.router.navigate(['/beneficiario']);
  }
  
}
