import { Component, OnInit } from '@angular/core';
import { ContactService } from '../services/contact.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-beneficiario',
  templateUrl: './beneficiario.component.html',
  styleUrls: ['./beneficiario.component.css']
})
export class BeneficiarioComponent implements OnInit {
  showModal = false;
  searchTerm: string = '';
  contacts: any[] = [];
  filteredContacts: any[] = [];
  
  selectedContactIndex: number | null = null;
  selectedContact: any = null;
  searchQuery: string = '';

  cuentaNombre: string | undefined;
  numeroCuenta: string | undefined;
  tipoCuenta: string | undefined;
  saldo: number | undefined;
  amount: number | undefined;
  usuario: string | undefined;
  numeroIdentidad: string | undefined;

  constructor(private contactService: ContactService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.cuentaNombre = params['cuentaNombre'];
      this.numeroCuenta = params['numeroCuenta'];
      this.tipoCuenta = params['tipoCuenta'];
      this.saldo = params['saldo'];
      this.amount = params['amount'];
      this.usuario = params['usuario'];
      this.numeroIdentidad = params['numeroIdentidad'];
      console.log('Received params:', params);
    });
    this.loadContacts();
  }

  actualizarListaContactos(): void {
    this.filteredContacts = this.contactService.getContacts();
  }

  loadContacts(): void {
    this.contacts = this.contactService.getContacts();
    this.filteredContacts = [...this.contacts];
  }

  filterContacts(): void {
    if (!this.searchTerm) {
      this.filteredContacts = [...this.contacts];
    } else {
      this.filteredContacts = this.contacts.filter(contact =>
        contact.name.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
    }
  }

  selectContact(contact: any): void {
    this.selectedContact = contact;
  }

  continue(): void {
    if (this.selectedContact) {
      this.router.navigate(['/confirmar-transferencia'], {
        queryParams: {
          cuentaNombre: this.cuentaNombre,
          numeroCuenta: this.numeroCuenta,
          tipoCuenta: this.tipoCuenta,
          saldo: this.saldo,
          amount: this.amount,
          contactName: this.selectedContact.name,
          contactNumber: this.selectedContact.number,
          usuario: this.usuario,
          numeroIdentidad: this.numeroIdentidad // Pass identity number
        }
      });
    }
  }

  goBack(): void {
    window.history.back();
  }

  toggleMenu(index: number, event: Event): void {
    event.stopPropagation();
    if (this.selectedContactIndex === index) {
      this.selectedContactIndex = null;
    } else {
      this.selectedContactIndex = index;
    }
  }

  deleteContact(index: number): void {
    this.contacts.splice(index, 1);
    this.filterContacts();
    this.selectedContactIndex = null;
  }

  addFavorite(contact: any): void {
    contact.isFavorite = !contact.isFavorite;
  }

  goToBeneficiario(): void {
    this.router.navigate(['/beneficiario']);
  }
}
