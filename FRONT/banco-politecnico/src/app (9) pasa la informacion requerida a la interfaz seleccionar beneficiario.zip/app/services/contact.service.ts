import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  private contacts: any[] = [];

  constructor() { }
  /*
  getContacts(): any[] {
    return this.contacts;
  }
    */




  getContacts(): any[] {
    // Ordenar los contactos: favoritos primero y luego por nombre
    return this.contacts.sort((a, b) => {
      if (a.isFavorite && !b.isFavorite) {
        return -1;
      } else if (!a.isFavorite && b.isFavorite) {
        return 1;
      } else {
        return a.name.localeCompare(b.name);
      }
    });
  }

  addContact(contact: any): void {
    this.contacts.push(contact);
    console.log('Contacto agregado:', contact); // Verifica en la consola que el contacto se está agregando correctamente
  }

  markAsFavorite(number: string): void {
    const contact = this.contacts.find(c => c.number === number);
    if (contact) {
      contact.isFavorite = true;
      console.log('Contacto marcado como favorito:', contact);
    }
  }
}