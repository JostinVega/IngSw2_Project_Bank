/*import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tipoCuentaService: TipoCuentaService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      nombreCuenta: [''],
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let nombreCuenta = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      nombreCuenta = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      nombreCuenta = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      nombreCuenta: nombreCuenta,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', nombreCuenta);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }
  

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.tipoCuentaService.saveCuenta().subscribe(response => {
        console.log('Cuenta guardada:', response);
        this.router.navigateByUrl('/confirmar-registro');
      }, error => {
        console.error('Error al guardar la cuenta:', error);
      });
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack() {
    // Implementa la función para retroceder si es necesario
  }
}*/

// src/app/tipo-cuenta/tipo-cuenta.component.ts
/*import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tipoCuentaService: TipoCuentaService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      nombreCuenta: [''],
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let nombreCuenta = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      nombreCuenta = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      nombreCuenta = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      nombreCuenta: nombreCuenta,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', nombreCuenta);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.tipoCuentaService.saveCuenta(this.accountSelectionForm.value).subscribe(response => {
        console.log('Cuenta guardada:', response);
        this.router.navigateByUrl('/confirmar-registro');
      }, error => {
        console.error('Error al guardar la cuenta:', error);
      });
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack() {
    // Implementa la función para retroceder si es necesario
  }
}
*/
/*import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tipoCuentaService: TipoCuentaService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      nombreCuenta: [''],
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let nombreCuenta = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      nombreCuenta = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      nombreCuenta = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      nombreCuenta: nombreCuenta,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', nombreCuenta);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.tipoCuentaService.saveCuenta(this.accountSelectionForm.value).subscribe(response => {
        console.log('Respuesta del servidor:', response);
        // Aquí puedes acceder a los datos específicos devueltos por el servidor
        // Por ejemplo:
        // const numeroCuenta = response.cuenta.numeroCuenta;
        // const tipoCuenta = response.cuenta.tipoCuenta;
        this.router.navigateByUrl('/confirmar-registro');
      }, error => {
        console.error('Error al guardar la cuenta:', error);
      });
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack() {
    // Implementa la función para retroceder si es necesario
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }
}
*/


/*import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tipoCuentaService: TipoCuentaService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      cuentaNombre: [''], // Asegúrate de que nombreCuenta esté presente en el formulario
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let cuentaNombre = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      cuentaNombre = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      cuentaNombre = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      cuentaNombre: cuentaNombre,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', cuentaNombre);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.tipoCuentaService.saveCuenta(this.accountSelectionForm.value).subscribe(response => {
        console.log('Respuesta del servidor:', response);
        this.router.navigateByUrl('/confirmar-registro');
      }, error => {
        console.error('Error al guardar la cuenta:', error);
      });
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack() {
    // Implementa la función para retroceder si es necesario
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }
}*/


// tipo-cuenta.component.ts
/*import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tipoCuentaService: TipoCuentaService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      cuentaNombre: [''],
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let cuentaNombre = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      cuentaNombre = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      cuentaNombre = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      cuentaNombre: cuentaNombre,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', cuentaNombre);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.tipoCuentaService.setAccountData(this.accountSelectionForm.value);
      this.tipoCuentaService.saveCuenta(this.accountSelectionForm.value).subscribe(response => {
        console.log('Respuesta del servidor:', response);
        this.router.navigateByUrl('/confirmar-registro');
      }, error => {
        console.error('Error al guardar la cuenta:', error);
      });
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack() {
    // Implementa la función para retroceder si es necesario
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }
}*/

/*import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistroService } from '../services/informacion-registro.service'; // Asegúrate de importar el servicio correcto

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent implements OnInit {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private registroService: RegistroService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      cuentaNombre: [''],
      tipoCuenta: ['']
    });
  }

  ngOnInit(): void {
    // Puedes inicializar datos adicionales si es necesario
  }

  generateAccount(accountType: string): void {
    let numeroCuenta = '';
    let cuentaNombre = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      cuentaNombre = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      cuentaNombre = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      cuentaNombre: cuentaNombre,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', cuentaNombre);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit(): void {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);

      this.registroService.setRegistrationData('step4', this.accountSelectionForm.value);
        this.router.navigateByUrl('/confirmar-registro');

      // Guardar datos del formulario usando RegistroService
      /*this.registroService.setRegistrationData('step', this.accountSelectionForm.value).subscribe({
        next: (response) => {
          console.log('Respuesta del servidor:', response);
          
        },
        error: (error) => {
          console.error('Error al guardar la cuenta:', error);
        }
      });*/
/*    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack(): void {
    // Implementa la función para retroceder si es necesario
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Implementa la lógica para verificar si el número de cuenta es único en tu sistema
    return true; // Por ahora siempre retorna true, deberías implementar la lógica adecuada
  }
}
*/

/*import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistroService } from '../services/informacion-registro.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent implements OnInit {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private registroService: RegistroService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      cuentaNombre: [''],
      tipoCuenta: ['']
    });
  }

  ngOnInit(): void {
    // Puedes inicializar datos adicionales si es necesario
  }

  goBack(): void {
    // Método para regresar, implementa la navegación o lógica necesaria
    this.router.navigateByUrl('/paso-anterior'); // Ejemplo de navegación
  }

  generateAccount(accountType: string): void {
    let numeroCuenta = '';
    let cuentaNombre = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      cuentaNombre = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      cuentaNombre = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      cuentaNombre: cuentaNombre,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', cuentaNombre);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit(): void {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);

      // Guardar datos del formulario usando RegistroService
      this.registroService.saveUser(this.accountSelectionForm.value).subscribe({
        next: (response) => {
          console.log('Respuesta del servidor:', response);
          // Redirigir a la siguiente página o componente después de guardar
          this.router.navigateByUrl('/confirmar-registro');
        },
        error: (error) => {
          console.error('Error al guardar la cuenta:', error);
        }
      });
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  // Métodos adicionales según sea necesario

  private generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  private generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  private isAccountNumberUnique(accountNumber: string): boolean {
    // Implementa la lógica para verificar si el número de cuenta es único en tu sistema
    return true; // Por ahora siempre retorna true, deberías implementar la lógica adecuada
  }
}*/

/*import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TipoCuentaService } from '../services/tipo-cuenta.service';
import { RegistroService } from '../services/informacion-registro.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private tipoCuentaService: TipoCuentaService,
    private registroService: RegistroService,
    private router: Router
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      cuentaNombre: [''],
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let cuentaNombre = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      cuentaNombre = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      cuentaNombre = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      cuentaNombre: cuentaNombre,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', cuentaNombre);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.registroService.setRegistrationData('step5', this.accountSelectionForm.value);
      this.tipoCuentaService.saveCuenta(this.accountSelectionForm.value).subscribe(response => {
        console.log('Respuesta del servidor:', response);
        this.router.navigateByUrl('/confirmar-registro');
      }, error => {
        console.error('Error al guardar la cuenta:', error);
      });
    } else {
      console.log('Formulario no válido');
    }
  }

  goBack() {
    window.history.back();
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }
}*/

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistroService } from '../services/informacion-registro.service';

@Component({
  selector: 'app-tipo-cuenta',
  templateUrl: './tipo-cuenta.component.html',
  styleUrls: ['./tipo-cuenta.component.css']
})
export class TipoCuentaComponent {
  accountSelectionForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private registroService: RegistroService // Inyectar el servicio
  ) {
    this.accountSelectionForm = this.fb.group({
      accountType: ['', Validators.required],
      numeroCuenta: [''],
      cuentaNombre: [''],
      tipoCuenta: ['']
    });
  }

  generateAccount(accountType: string) {
    let numeroCuenta = '';
    let cuentaNombre = '';
    let tipoCuentaTexto = '';

    if (accountType === 'savings') {
      numeroCuenta = this.generateUniqueAccountNumber('2');
      cuentaNombre = `AHORRO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Ahorro';
    } else if (accountType === 'current') {
      numeroCuenta = this.generateUniqueAccountNumber('5');
      cuentaNombre = `CREDITO-${numeroCuenta.slice(-3)}`;
      tipoCuentaTexto = 'Crédito';
    }

    this.accountSelectionForm.patchValue({
      numeroCuenta: numeroCuenta,
      cuentaNombre: cuentaNombre,
      tipoCuenta: tipoCuentaTexto
    });

    console.log('Número de cuenta:', numeroCuenta);
    console.log('Nombre de cuenta:', cuentaNombre);
    console.log('Tipo de cuenta:', tipoCuentaTexto);
  }

  onSubmit() {
    if (this.accountSelectionForm.valid) {
      const accountType = this.accountSelectionForm.value.accountType;
      this.generateAccount(accountType);
      this.registroService.setRegistrationData('step5', this.accountSelectionForm.value);
      this.router.navigateByUrl('/confirmar-registro');
    } else {
      // Manejar el caso de que el formulario no sea válido
    }
  }

  goBack() {
    // Implementa la función para retroceder si es necesario
  }

  generateUniqueAccountNumber(startsWith: string): string {
    let newAccountNumber;
    do {
      newAccountNumber = startsWith + this.generateRandomNumberString(9);
    } while (!this.isAccountNumberUnique(newAccountNumber));
    return newAccountNumber;
  }

  generateRandomNumberString(length: number): string {
    let result = '';
    const characters = '0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  isAccountNumberUnique(accountNumber: string): boolean {
    // Aquí iría la lógica para verificar si el número de cuenta es único en tu sistema
    return true;
  }
}

