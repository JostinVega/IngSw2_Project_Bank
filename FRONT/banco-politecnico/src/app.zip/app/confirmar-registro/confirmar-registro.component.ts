/*import { Component, OnInit } from '@angular/core';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  cuentaNombre: string | undefined;
  cuentaNumero: string | undefined;
  tipoCuenta: string | undefined; // Define tipoCuenta aquí

  constructor(
    private tipoCuentaService: TipoCuentaService,
  ) { }

  ngOnInit(): void {
    this.cuentaNombre = this.tipoCuentaService.getNombreCuenta();
    this.cuentaNumero = this.tipoCuentaService.getNumeroCuenta();
    this.tipoCuenta = this.determinarTipoCuenta(); // Asegúrate de obtener el tipo de cuenta correctamente
  }

  determinarTipoCuenta(): string {
    // Aquí deberías implementar la lógica para determinar el tipo de cuenta
    // Puedes obtener esta información desde el servicio registroService o de alguna otra fuente
  
    // Ejemplo básico:
    if (this.cuentaNumero && this.cuentaNumero.startsWith('2')) {
      return 'Ahorro';
    } else if (this.cuentaNumero && this.cuentaNumero.startsWith('5')) {
      return 'Crédito';
    } else {
      return 'Tipo no determinado'; // Manejar otros casos según tu lógica
    }
  }
  
}
*/

/*import { Component, OnInit } from '@angular/core';
import { TipoCuentaService } from '../services/tipo-cuenta.service';

@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  numeroCuenta: string | undefined;
  cuentaNombre: string | undefined;
  tipoCuenta: string | undefined;

  constructor(private tipoCuentaService: TipoCuentaService) { }

  ngOnInit() {
    const cuenta = this.tipoCuentaService.getCuenta();
    this.numeroCuenta = cuenta.numeroCuenta;
    this.cuentaNombre = cuenta.cuentaNombre;
    this.tipoCuenta = cuenta.tipoCuenta;
  }
}*/


// confirmar-registro.component.ts
/*import { Component, OnInit } from '@angular/core';
import { TipoCuentaService } from '../services/tipo-cuenta.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  tipoCuenta: string | undefined;
  cuentaNombre: string | undefined;
  numeroCuenta: string | undefined;

  constructor(private tipoCuentaService: TipoCuentaService,
    private router: Router
  ) { }

  ngOnInit(): void {
    const accountData = this.tipoCuentaService.getAccountData();
    this.tipoCuenta = accountData.tipoCuenta;
    this.cuentaNombre = accountData.cuentaNombre;
    this.numeroCuenta = accountData.numeroCuenta;
  }

  onSubmit(): void {
    this.router.navigateByUrl('/inicio');
    console.log('Formulario enviado');
    //console.log('Respuesta del servidor:', response);
  }
}*/

// confirmar-registro.component.ts

/*import { Component, OnInit } from '@angular/core';
import { RegistroService } from '../services/informacion-registro.service';  // Importar RegistroService
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  cuentaNombre: string | undefined;
  cuentaNumero: string | undefined;
  tipoCuenta: string | undefined; // Define tipoCuenta aquí

  constructor(private registroService: RegistroService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.cuentaNombre = this.registroService.getRegistrationData().cuentaNombre;
    this.cuentaNumero = this.registroService.getRegistrationData().numeroCuenta;
    this.tipoCuenta = this.determinarTipoCuenta(); // Asegúrate de obtener el tipo de cuenta correctamente
  }

  determinarTipoCuenta(): string {
    // Implementa la lógica para determinar el tipo de cuenta aquí
    return 'Ahorro'; // Ejemplo básico, ajusta según tu lógica real
  }

  onSubmit(): void {
    console.log('Iniciar sesión o enviar información a la base de datos');
    // Aquí puedes implementar la lógica para iniciar sesión o enviar la información a la base de datos
    this.router.navigateByUrl('/inicio'); // Ejemplo de navegación
  }
}
*/

/*import { Component, OnInit } from '@angular/core';
import { RegistroService } from '../services/informacion-registro.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  cuentaNombre: string | undefined;
  cuentaNumero: string | undefined;
  tipoCuenta: string | undefined;

  private apiUrl: string;

  constructor(private registroService: RegistroService,
              private router: Router,
              private http: HttpClient) { 
                this.apiUrl = environment.apiUrl;
              }

  ngOnInit(): void {
    const registrationData = this.registroService.getAllData();
    this.cuentaNombre = registrationData.step5.cuentaNombre;
    this.cuentaNumero = registrationData.step5.numeroCuenta;
    this.tipoCuenta = registrationData.step5.tipoCuenta;
  }

  onSubmit(): void {
    const registrationData = this.registroService.getAllData();
    this.http.post(`${this.apiUrl}/nuevo-usuario`, registrationData).subscribe(
      response => {
        console.log('Datos enviados con éxito:', response);
        this.router.navigate(['/inicio']);
      },
      error => {
        console.error('Error al enviar los datos:', error);
      }
    );
  }

  determinarTipoCuenta(): string {
    // Implementa la lógica para determinar el tipo de cuenta aquí
    return this.tipoCuenta || 'Desconocido'; // Ajusta según tu lógica real
  }
}
*/

/*import { Component, OnInit } from '@angular/core';
import { RegistroService } from '../services/informacion-registro.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  cuentaNombre: string | undefined;
  cuentaNumero: string | undefined;
  tipoCuenta: string | undefined;

  constructor(private registroService: RegistroService,
              private router: Router) { }

  ngOnInit(): void {
    const registrationData = this.registroService.getAllData();
    this.cuentaNombre = registrationData.step5.cuentaNombre;
    this.cuentaNumero = registrationData.step5.numeroCuenta;
    this.tipoCuenta = registrationData.step5.tipoCuenta;
  }

  onSubmit(): void {
    const registrationData = this.registroService.getAllData();
    this.registroService.registrarUsuario(registrationData).subscribe(
      response => {
        console.log('Datos enviados con éxito:', response);
        this.router.navigate(['/inicio']);
      },
      error => {
        console.error('Error al enviar los datos:', error);
      }
    );
  }

  determinarTipoCuenta(): string {
    return this.tipoCuenta || 'Desconocido';
  }
}*/

import { Component, OnInit } from '@angular/core';
import { RegistroService } from '../services/informacion-registro.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-confirmar-registro',
  templateUrl: './confirmar-registro.component.html',
  styleUrls: ['./confirmar-registro.component.css']
})
export class ConfirmarRegistroComponent implements OnInit {
  cuentaNombre: string | undefined;
  cuentaNumero: string | undefined;
  tipoCuenta: string | undefined;

  constructor(private registroService: RegistroService,
              private router: Router) { }

  ngOnInit(): void {
    const registrationData = this.registroService.getAllData();
    console.log('Datos recibidos para registrar:', registrationData); // Log para verificar datos

    this.cuentaNombre = registrationData.step5?.cuentaNombre;
    this.cuentaNumero = registrationData.step5?.numeroCuenta;
    this.tipoCuenta = registrationData.step5?.tipoCuenta;
  }

  onSubmit(): void {
    const registrationData = this.registroService.getAllData();
    this.registroService.registrarUsuario(registrationData).subscribe(
      response => {
        console.log('Datos enviados con éxito:', response);
        this.router.navigate(['/inicio']);
      },
      error => {
        console.error('Error al enviar los datos:', error);
      }
    );
  }
}

