/*import { Component, OnInit } from '@angular/core';
impiort { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CrearUsuarioService } from '../services/crear-usuario.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.css']
})
export class CrearUsuarioComponent implements OnInit {
  registrationForm: FormGroup;

  constructor(private fb: FormBuilder,
    private crearUsuarioService: CrearUsuarioService,
    private router: Router
  ) {
    this.registrationForm = this.fb.group({
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(20),
          Validators.pattern('^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9._-]+$'),
          this.checkUsernameStrength.bind(this) // Custom validator function
        ]
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(64),
          Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[A-Za-z\\d!@#$%^&*].{8,}$')
        ]
      ],
      confirmPassword: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator // Custom validator for password match
    });
  }

  ngOnInit() {}

  checkUsernameStrength(control: any): { [key: string]: boolean } | null {
    const username = control.value;

    // Check if username is too simple (example: 'aaaaaa')
    if (/^(.)\1{2,}$/.test(username)) {
      return { tooSimple: true };
    }

    return null;
  }

  passwordMatchValidator(group: FormGroup) {
    const password = group.get('password')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;

    return password === confirmPassword ? null : { mismatch: true };
  }

  onSubmit() {
    if(this.registrationForm.valid){
      this.crearUsuarioService.compareUser(this.registrationForm.value).subscribe(
        response => {
                this.router.navigateByUrl('/preguntas-seguridad');
                console.log('Usuario registrado con éxito:', response);
              },
              error => {
                console.error('Error al registrar el usuario:', error);
              }  
      )
    }
  }
}*/

/*import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegistroService } from '../services/informacion-registro.service';  // Importar RegistroService
import { Router } from '@angular/router';

@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.css']
})
export class CrearUsuarioComponent implements OnInit {
  registrationForm: FormGroup;

  constructor(private fb: FormBuilder,
              private registroService: RegistroService,  // Inyectar RegistroService
              private router: Router
  ) {
    this.registrationForm = this.fb.group({
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(20),
          Validators.pattern('^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9._-]+$'),
          this.checkUsernameStrength.bind(this) // Función validadora personalizada
        ]
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(64),
          Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[A-Za-z\\d!@#$%^&*].{8,}$')
        ]
      ],
      confirmPassword: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator // Validador personalizado para coincidencia de contraseñas
    });
  }

  ngOnInit() {}

  checkUsernameStrength(control: any): { [key: string]: boolean } | null {
    const username = control.value;

    // Verificar si el nombre de usuario es demasiado simple (ejemplo: 'aaaaaa')
    if (/^(.)\1{2,}$/.test(username)) {
      return { tooSimple: true };
    }

    return null;
  }

  passwordMatchValidator(group: FormGroup) {
    const password = group.get('password')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;

    return password === confirmPassword ? null : { mismatch: true };
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      this.registroService.setRegistrationData('step3', {
        username: this.registrationForm.value.username,
        password: this.registrationForm.value.password
      });
      this.router.navigate(['/preguntas-seguridad']);
    }
  }
}
*/

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegistroService } from '../services/informacion-registro.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.css']
})
export class CrearUsuarioComponent implements OnInit {
  registrationForm: FormGroup;

  constructor(private fb: FormBuilder,
              private registroService: RegistroService, // Inyectar RegistroService
              private router: Router) {
    this.registrationForm = this.fb.group({
      username: [
        '',
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(20),
          Validators.pattern('^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9._-]+$'),
          this.checkUsernameStrength.bind(this) // Custom validator function
        ]
      ],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(64),
          Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[A-Za-z\\d!@#$%^&*].{8,}$')
        ]
      ],
      confirmPassword: ['', [Validators.required]]
    }, {
      validators: this.passwordMatchValidator // Custom validator for password match
    });
  }

  ngOnInit() {}

  checkUsernameStrength(control: any): { [key: string]: boolean } | null {
    const username = control.value;

    // Check if username is too simple (example: 'aaaaaa')
    if (/^(.)\1{2,}$/.test(username)) {
      return { tooSimple: true };
    }

    return null;
  }

  passwordMatchValidator(group: FormGroup) {
    const password = group.get('password')?.value;
    const confirmPassword = group.get('confirmPassword')?.value;

    return password === confirmPassword ? null : { mismatch: true };
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      this.registroService.setRegistrationData('step3', this.registrationForm.value);
      this.router.navigate(['/preguntas-seguridad']);
    } else {
      console.error('Formulario no válido');
    }
  }
}
