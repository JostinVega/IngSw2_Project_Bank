import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ContactService } from '../services/contact.service'; // Asegúrate de ajustar la ruta según la ubicación de tu servicio

@Component({
  selector: 'app-agregar-beneficiario',
  templateUrl: './agregar-beneficiario.component.html',
  styleUrls: ['./agregar-beneficiario.component.css']
})
export class AgregarBeneficiarioComponent {
  beneficiary = {
    name: '',
    accountNumber: '',
    saveToContacts: false,
    saveAsFavorite: false
  };

  showModal = false;

  constructor(private router: Router, private contactService: ContactService) { }

  confirmBeneficiary(): void {
    if (this.isAccountNumberValid() && this.isBeneficiaryNameValid()) {
      console.log('Beneficiario agregado:', this.beneficiary);
      this.contactService.addContact({
        initials: this.beneficiary.name.charAt(0), // Calcula las iniciales basadas en el nombre, ajusta según tu lógica
        name: this.beneficiary.name,
        type: 'Aho', // Ajusta el tipo según tu lógica
        number: this.beneficiary.accountNumber,
        saveToContacts: this.beneficiary.saveToContacts,
        saveAsFavorite: this.beneficiary.saveAsFavorite
        
      });
      if (this.beneficiary.saveAsFavorite) {
        this.contactService.markAsFavorite(this.beneficiary.accountNumber); // Marcar como favorito
      }
      this.showModal = true;
    } else {
      alert('Ingrese un número de cuenta válido.');
    }
  }

  isAccountNumberValid(): boolean {
    return /^\d{10}$/.test(this.beneficiary.accountNumber);
  }

  isBeneficiaryNameValid(): boolean {
    return /^[a-zA-Z\s]+$/.test(this.beneficiary.name);
  }

  goToBeneficiario(): void {
    this.showModal = false;
    this.router.navigate(['/beneficiario']);
  }

  goNext(): void {
    this.showModal = false;
    console.log('Ir a la siguiente pantalla');
  }

  goBack(): void {
    this.router.navigate(['/beneficiario']);
  }

  onAccountNumberChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    input.value = input.value.replace(/\D/g, '').substring(0, 10);
    this.beneficiary.accountNumber = input.value;
  }

  onNameChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
    this.beneficiary.name = input.value;
  }
}