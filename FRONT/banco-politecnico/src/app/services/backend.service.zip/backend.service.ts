import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BackendService {
  private backendUrl = 'http://localhost:4001'; // URL para el backend principal

  constructor(private http: HttpClient) {}

  uploadComprobante(formData: FormData): Observable<any> {
    return this.http.post(`${this.backendUrl}/upload-comprobante`, formData);
  }
}
