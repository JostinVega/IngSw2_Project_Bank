import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { PasswordService } from '../services/password.service.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent {
  currentPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  numeroIdentidad: string = '';// Pasar el numero de Identidad

  constructor(private router: Router, private passwordService: PasswordService) {}

  goBack() {
    this.router.navigate(['/previous-route']);
  }

  changePassword() {
    if (this.newPassword !== this.confirmPassword) {
      alert('Las contraseñas no coinciden. Por favor, inténtelo de nuevo.');
      return;
    }

    if (!this.isPasswordValid(this.newPassword)) {
      alert('La contraseña no cumple con los requisitos de seguridad.');
      return;
    }

    const payload = {
      contrasena_actual: this.currentPassword,
      nueva_contrasena: this.newPassword
    };

    this.passwordService.changePassword(this.numeroIdentidad, payload).subscribe(
      (response: any) => {
        console.log('Password changed successfully.', response);
        this.router.navigate(['/confirm-change-password']);
      },
      (error: any) => {
        console.error('Error changing password:', error);
        alert('Error al cambiar la contraseña. Por favor, inténtelo de nuevo.');
      
  });
}

  isPasswordValid(password: string): boolean {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
  }
}