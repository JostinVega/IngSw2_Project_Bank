import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-confirmar-transferencia',
  templateUrl: './confirmar-transferencia.component.html',
  styleUrls: ['./confirmar-transferencia.component.css']
})
export class ConfirmarTransferenciaComponent implements OnInit {
  cuentaNombre: string | undefined;
  numeroCuenta: string | undefined;
  tipoCuenta: string | undefined;
  saldo: number | undefined;
  amount: number | undefined;
  usuario: string | undefined;
  numeroIdentidad: string | undefined;
  contactName: string | undefined;
  contactNumber: string | undefined;
  comment: string | undefined;

  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.cuentaNombre = params['cuentaNombre'];
      this.numeroCuenta = params['numeroCuenta'];
      this.tipoCuenta = params['tipoCuenta'];
      this.saldo = params['saldo'];
      this.amount = params['amount'];
      this.usuario = params['usuario'];
      this.numeroIdentidad = params['numeroIdentidad'];
      this.contactName = params['contactName'];
      this.contactNumber = params['contactNumber'];
      this.comment = params['comment'];
    });
  }

  confirmTransfer(): void {
    console.log('Transferencia confirmada con los siguientes datos:');
    console.log('Cuenta Nombre:', this.cuentaNombre);
    console.log('Número Cuenta:', this.numeroCuenta);
    console.log('Tipo Cuenta:', this.tipoCuenta);
    console.log('Saldo:', this.saldo);
    console.log('Monto:', this.amount);
    console.log('Usuario:', this.usuario);
    console.log('Número de Identidad:', this.numeroIdentidad);
    console.log('Nombre del Contacto:', this.contactName);
    console.log('Número del Contacto:', this.contactNumber);
    console.log('Comentario:', this.comment);
    // Aquí iría la lógica para procesar la transferencia
  }

  cancelTransfer(): void {
    this.router.navigate(['/']);
  }

  goBack(): void {
    this.router.navigate(['/agregar-comentario']);
  }
}
