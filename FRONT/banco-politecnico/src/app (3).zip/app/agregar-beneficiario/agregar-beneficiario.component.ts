import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-agregar-beneficiario',
  templateUrl: './agregar-beneficiario.component.html',
  styleUrls: ['./agregar-beneficiario.component.css']
})
export class AgregarBeneficiarioComponent {
    beneficiary = {
    name: '',
    accountNumber: '',
    saveToContacts: false,
    saveAsFavorite: false
  };

  showModal = false;

  constructor(private router: Router) { }

  confirmBeneficiary(): void {
    // Aquí puedes agregar la lógica para guardar el beneficiario
    console.log('Beneficiario agregado:', this.beneficiary);
    this.showModal = true;
  }

  goNext(): void {
    this.showModal = false;
    // Aquí puedes agregar la lógica para ir a la siguiente pantalla
    console.log('Ir a la siguiente pantalla');
  }

  goBack(): void {
    // Aquí puedes agregar la lógica para regresar a la pantalla anterior
    this.router.navigate(['/beneficiario']); // Asegúrate de tener configurada la ruta
  }
}
