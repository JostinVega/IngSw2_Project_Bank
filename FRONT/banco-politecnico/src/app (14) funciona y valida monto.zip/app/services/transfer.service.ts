import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TransferService {
  private transferData: any = {};

  setTransferData(data: any): void {
    this.transferData = data;
  }

  getTransferData(): any {
    return this.transferData;
  }
}
