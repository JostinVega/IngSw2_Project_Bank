import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactService } from '../services/contact.service';

@Component({
  selector: 'app-agregar-beneficiario',
  templateUrl: './agregar-beneficiario.component.html',
  styleUrls: ['./agregar-beneficiario.component.css']
})
export class AgregarBeneficiarioComponent implements OnInit {
  beneficiary = {
    name: '',
    accountNumber: '',
    saveToContacts: false,
    saveAsFavorite: false
  };

  cuentaNombre: string | undefined;
  numeroCuenta: string | undefined;
  tipoCuenta: string | undefined;
  saldo: number | undefined;
  amount: number | undefined;
  usuario: string | undefined;
  numeroIdentidad: string | undefined;

  showModal = false;

  constructor(private router: Router, private contactService: ContactService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.cuentaNombre = params['cuentaNombre'];
      this.numeroCuenta = params['numeroCuenta'];
      this.tipoCuenta = params['tipoCuenta'];
      this.saldo = params['saldo'];
      this.amount = params['amount'];
      this.usuario = params['usuario'];
      this.numeroIdentidad = params['numeroIdentidad'];
      console.log('Received params:', params);
    });
  }

  confirmBeneficiary(): void {
    if (this.isAccountNumberValid() && this.isBeneficiaryNameValid()) {
      console.log('Beneficiario agregado:', this.beneficiary);
      this.contactService.addContact({
        initials: this.beneficiary.name.charAt(0),
        name: this.beneficiary.name,
        type: 'Aho',
        number: this.beneficiary.accountNumber,
        saveToContacts: this.beneficiary.saveToContacts,
        saveAsFavorite: this.beneficiary.saveAsFavorite
      });
      if (this.beneficiary.saveAsFavorite) {
        this.contactService.markAsFavorite(this.beneficiary.accountNumber);
      }
      this.showModal = true;
    } else {
      alert('Ingrese un número de cuenta válido.');
    }
  }

  isAccountNumberValid(): boolean {
    return /^\d{10}$/.test(this.beneficiary.accountNumber);
  }

  isBeneficiaryNameValid(): boolean {
    return /^[a-zA-Z\s]+$/.test(this.beneficiary.name);
  }

  goToBeneficiario(): void {
    this.showModal = false;
    this.router.navigate(['/beneficiario'], {
      queryParams: {
        cuentaNombre: this.cuentaNombre,
        numeroCuenta: this.numeroCuenta,
        tipoCuenta: this.tipoCuenta,
        saldo: this.saldo,
        amount: this.amount,
        usuario: this.usuario,
        numeroIdentidad: this.numeroIdentidad
      }
    });
  }

  goNext(): void {
    this.showModal = false;
    console.log('Ir a la siguiente pantalla');
  }

  goBack(): void {
    this.router.navigate(['/beneficiario'], {
      queryParams: {
        cuentaNombre: this.cuentaNombre,
        numeroCuenta: this.numeroCuenta,
        tipoCuenta: this.tipoCuenta,
        saldo: this.saldo,
        amount: this.amount,
        usuario: this.usuario,
        numeroIdentidad: this.numeroIdentidad
      }
    });
  }

  onAccountNumberChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    input.value = input.value.replace(/\D/g, '').substring(0, 10);
    this.beneficiary.accountNumber = input.value;
  }

  onNameChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    input.value = input.value.replace(/[^a-zA-Z\s]/g, '');
    this.beneficiary.name = input.value;
  }
}
