import { Component, OnInit, Renderer2, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit, AfterViewInit {
  currentIndex: number = 0;
  totalCards: number = 0;

  constructor(
    private renderer: Renderer2,
    private router: Router
  ) {}

  ngOnInit(): void {
    window.addEventListener('resize', this.updateNavigation.bind(this));
  }

  ngAfterViewInit(): void {
    this.totalCards = document.querySelectorAll('.account-card').length;
    this.updateNavigation();
  }

  updateNavigation(): void {
    const accountCardsWrapper = document.getElementById('accountCardsWrapper');
    const accountNavLeft = document.getElementById('accountNavLeft');
    const accountNavRight = document.getElementById('accountNavRight');

    if (!accountCardsWrapper || !accountNavLeft || !accountNavRight) {
      return;
    }

    const cardWidth = accountCardsWrapper.children[0].clientWidth + 20; // Card width + margin

    if (this.totalCards <= 2) {
      this.renderer.setStyle(accountNavLeft, 'display', 'none');
      this.renderer.setStyle(accountNavRight, 'display', 'none');
    } else {
      this.renderer.setStyle(accountNavLeft, 'display', this.currentIndex === 0 ? 'none' : 'flex');
      this.renderer.setStyle(accountNavRight, 'display', this.currentIndex >= this.totalCards - 2 ? 'none' : 'flex');
    }

    const offset = -this.currentIndex * cardWidth;
    this.renderer.setStyle(accountCardsWrapper, 'transform', `translateX(${offset}px)`);
  }

  navLeft(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.updateNavigation();
    }
  }

  navRight(): void {
    if (this.currentIndex < this.totalCards - 2) {
      this.currentIndex++;
      this.updateNavigation();
    }
  }
}
