import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service'; 

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  homeForm: FormGroup;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.homeForm = this.fb.group({
      usuario: ['', Validators.required],
      contrasena: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.homeForm.valid) {
      console.log('Formulario válido', this.homeForm.value);
      this.authService.login(this.homeForm.value).subscribe(
        (response: any) => {
          console.log('Login response:', response);
          if (response.success) {
            console.log('Redirigiendo a /inicio');
            this.router.navigate(['/inicio']);
          } else {
            alert(response.message);
          }
        },
        (error: any) => {
          console.error('Error during login:', error);
        }
      );
    } else {
      console.log('Formulario inválido');
    }
  }
  
  
}


