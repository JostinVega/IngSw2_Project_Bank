import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-beneficiario',
  templateUrl: './beneficiario.component.html',
  styleUrls: ['./beneficiario.component.css']
})
export class BeneficiarioComponent implements OnInit {
  searchTerm: string = '';
  contacts = [
    { initials: 'J', name: 'Jostin Vega', number: '2309807866', type: 'Aho' },
    { initials: 'E', name: 'Enrique Morales', number: '2465780945', type: 'Aho' },
    { initials: 'L', name: 'Lucia Morales', number: '2786078901', type: 'Aho' },
    { initials: 'A', name: 'Alexander Pillajo', number: '2657080098', type: 'Aho' }
  ];
  filteredContacts = [...this.contacts];
  selectedContactIndex: number | null = null;

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  filterContacts(): void {
    this.filteredContacts = this.contacts.filter(contact => 
      contact.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      contact.number.includes(this.searchTerm)
    );
  }

  toggleMenu(index: number): void {
    if (this.selectedContactIndex === index) {
      this.selectedContactIndex = null;
    } else {
      this.selectedContactIndex = index;
    }
  }

  deleteContact(index: number): void {
    this.contacts.splice(index, 1);
    this.filterContacts();
    this.selectedContactIndex = null;
  }

  goBack(): void {
    // Implementar la lógica para volver a la página anterior
    console.log('Volver a la página anterior');
    this.router.navigate(['/transfer']);
  }

  addFavorite(contact: any): void {
    // Aquí puedes agregar la lógica para marcar como favorito
    console.log('Agregado como favorito:', contact);
    this.selectedContactIndex = null;
  }
}
